#ifdef HAS_LP5562
#include <Wire.h>

#include <LP5562.h>
extern LP5562 rgbw;

#endif